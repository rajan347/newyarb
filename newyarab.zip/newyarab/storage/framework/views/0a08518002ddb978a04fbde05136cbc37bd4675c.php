<html>
<body>

<h3>alluser</h3>

<table>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
<?php echo e($users->first_name); ?>

<?php echo e($users->last_name); ?>

<?php echo e($users->dob); ?>

<?php echo e($users->email); ?>

<?php echo e($users->subscription); ?>

<form method="get" action="<?php echo e(route('../edituser'.'/'.$users->id)); ?>" >
<button type="button">edit</button>
</form>
<button type="button" action="<?php echo e(route('/deleteuser'.'/'.$users->id)); ?>">delete</button>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</table>
</body>
</html><?php /**PATH C:\wamp\www\project\newyarab\resources\views/admin/alluser.blade.php ENDPATH**/ ?>